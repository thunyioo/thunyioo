// Package missinggo contains miscellaneous helpers used in many of anacrolix'
// projects.
package missinggo
